<?php
header("Location: ../");
exit;