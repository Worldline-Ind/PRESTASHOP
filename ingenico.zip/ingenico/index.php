<?php
header("Location: ../");
exit;